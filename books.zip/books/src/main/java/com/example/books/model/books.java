package com.example.books.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class books {
	@Id
	private int sno;
	private int bkno;
	private int pgno;
	private String name;
	private String department;
	private String author;
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public int getBkno() {
		return bkno;
	}
	public void setBkno(int bkno) {
		this.bkno = bkno;
	}
	public int getPgno() {
		return pgno;
	}
	public void setPgno(int pgno) {
		this.pgno = pgno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	

}
