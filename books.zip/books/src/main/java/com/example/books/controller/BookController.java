package com.example.books.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.books.model.books;
import com.example.books.service.BookService;

@RestController
public class BookController {
	
	@Autowired
	BookService bkService;
	@GetMapping(value="/fetchBooks")
	public List<books> getAllBooks()
	{
		List<books> bkList=bkService.getAllBooks();
		return bkList;
	}
	
	@PostMapping(value="/saveBook")
	public books saveBook(@RequestBody books b)
	{
		return bkService.saveBook(b);
		
	}
	
	@PutMapping(value="/updateBook")
	public books updateBook(@RequestBody books b)
	{
		return bkService.updateBook(b);
		
	}
	
	@DeleteMapping("/deleteBook/{bkno}")
	public void deleteBook(@PathVariable("bkno") int bkno)
	{
		bkService.deleteBook(bkno);
		
	}
}
