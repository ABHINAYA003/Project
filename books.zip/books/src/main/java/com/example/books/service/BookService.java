package com.example.books.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.books.dao.BookRepository;
import com.example.books.model.books;

@Service
public class BookService {
	@Autowired
	BookRepository bkRepository;

	public List<books> getAllBooks()
	{
		List<books> bkList=bkRepository.findAll();
		return bkList;
	}

	public books saveBook(books b) 
	{
		return  bkRepository.save(b);
		//return bkRepository.save(b);	
	}

	public books updateBook(books b) 
	{
		return bkRepository.save(b);
	}

	public void deleteBook(int bkno) 
	{
		bkRepository.deleteById(bkno);
	}
	}
